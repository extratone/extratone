# Biographical

[BBL Bio](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/BBL%20Bio%20c563f96aa25b4db09c8f86e721b0fe68.md)

> **A whirlwind of bitchery spinning round a wild, wholesome little yokel.**

[](https://www.notion.so/9fdc8e9610b34b8f991ebc148b760055) 

[Rollodex](https://www.notion.so/Rollodex-82a7d02f4bed4c06883da9c353ac7ce5)

[David Blue's Astrological Chart (Via Co-Star)](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/David%20Blue's%20Astrological%20Chart%20(Via%20Co-Star)%209c425ae3e81f4470ad9e2490a3a8f02c.md)

[Introduction to The W-Word](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/Introduction%20to%20The%20W-Word%20e6aa205f36844c56bfe4c4fa0d6d7feb.md)

---

[Why I Write About Technology](https://bilge.world/personal-technology-history)

[https://gist.github.com/extratone/91ebe16b0c620f309e70b40f5d4dcd9e](https://gist.github.com/extratone/91ebe16b0c620f309e70b40f5d4dcd9e)

# Social Bios

lapsed auto writer & self-described software historian. through Motorsport all things are possible. • [davidblue@extratone.com](mailto:davidblue@extratone.com) • ⒽⒺ ⚫ ⒽⒾⓂ (Updated Oct 22, 2020 2:31 PM)

lapsed auto writer & 100% Open Source Bitch. through Motorsport all things are possible. • [davidblue@extratone.com](mailto:davidblue@extratone.com) • ⒽⒺ ⚫ ⒽⒾⓂ

lapsed auto writer & word processing stan. through Motorsport all things are possible. • [davidblue@extratone.com](mailto:davidblue@extratone.com) • ⒽⒺ ⚫ ⒽⒾⓂ

[https://gist.github.com/extratone/17a761e1176c8da6883128758eb68191](https://gist.github.com/extratone/17a761e1176c8da6883128758eb68191)

## Mastodon

Editor-in-Chief, Neoyokel, Screwston Loyalist, Angst Wrangler, Literacy Advocate, Lapsed Car Writer, and 100% Open Source Bitch.

ⒽⒺ ⚫︎ ⒽⒾⓂ︎
Posts about media and The Web.

[davidblue@extratone.com](mailto:davidblue@extratone.com)

Editor-in-Chief, Neoyokel, Screwston Loyalist, Angst Wrangler, Literacy Advocate, Lapsed Car Writer, and Word Processing Stan.

ⒽⒺ ⚫︎ ⒽⒾⓂ︎
Posts about media and The Web.

[davidblue@extratone.com](mailto:davidblue@extratone.com)

## Reddit

Editor-in-Chief, Neoyokel, Angst Wrangler, Literacy Advocate, Computing Historian, and 100% Open Source Bitch.

[DiaspBio.md](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/DiaspBio.md)

[Mastodon Introduction](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/Mastodon%20Introduction%2013c355d1dd8c405ea5b98f51751a2cd0.md)

---

- Legacy

    Jul 20, 2016 4:42 AM 

    David Blue is the Founder and Editor-in-Chief of *Extratone* and the originator of "Drywall," the counter-counterculture from which it formed. His work has thus far been defined by his chronologically-inappropriate use of the phrase "good morning."

    Editor-in-Chief David Blue brings us along for the journey as he attempts to tackle the blog medium and his tediously-fickle intellect simultaneously.

[David Blue Bio](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/David%20Blue%20Bio%2014e3772fcd8a4b41a1ddab7eadb17ead.md)

[The Dave That Identifies Friends By Their Occupation](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/The%20Dave%20That%20Identifies%20Friends%20By%20Their%20Occupati%201343cc00b6234e94bcf3c500bbd3042d.md)

[The Day of Reformed Precocity](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/The%20Day%20of%20Reformed%20Precocity%201bbbb5f6369646fbae7024c3295523e4.md)

[Written Influences](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/Written%20Influences%204482c85759ea486aabe62275d7502c4d.md)

### Interviews

["Chat With David Blue" | Writeas Community](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/Chat%20With%20David%20Blue%20Writeas%20Community%20e7420bfc93754c9a9c5e4ef2bbb16181.md)

[David Blue Interviewed By Null](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/David%20Blue%20Interviewed%20By%20Null%209dbcf2372c3848c2922897b84ddf8cab.md)

[David Blue Ben Astarb Interview](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/David%20Blue%20Ben%20Astarb%20Interview%2087bf310ba32542e395c63908a67522f2.md)

[https://www.merriam-webster.com/dictionary/navel-gazing](https://www.merriam-webster.com/dictionary/navel-gazing)

[Page title...](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/Page%20title%20e8170653267d4b8cb8a5b6f0f6e93c9f.md)

[About — Extratone](Biographical%20d0499d3568b84c0a9f4b732b20302bdd/About%20%E2%80%94%20Extratone%20c48315db412848f6b048c04043cf3790.md)