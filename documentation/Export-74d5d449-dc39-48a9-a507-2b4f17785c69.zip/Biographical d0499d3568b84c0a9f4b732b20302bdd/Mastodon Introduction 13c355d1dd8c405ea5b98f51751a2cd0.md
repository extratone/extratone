# Mastodon Introduction

# Mastodon Introduction

Hello!

I’m David Blue and little is left of my day-to-day life apart from my online magazine & community, called Extratone. ( [http://extratone.com](http://extratone.com/) /about) They’re the best bunch. Some are here; more are coming.

Words and their storytelling are extraordinarily significant to me, though I’m not good with either, in the academic sense. I used to be funny? but am now much too sincere.