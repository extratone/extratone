# The Dave That Identifies Friends By Their Occupation

**[TO BE PROPERLY ARCHIVED]**

After a discussion with mom, I've realized that I have an unusual tendency to identify people by their occupation (or that which they aspire to,) even moreso than them, usually. For instance, I first ask new employees what their major is, and then spend a huge chunk of my dialogue with them making jokes about their future life. Logan, for instance, is majoring in Political Science and intends to be a corporate lawyer, so I spend a fair amount of time making golf and corporate lingo jokes with him, as well as talking about the particular perils of corporate law in the automotive industry. I think I sometimes *remind* Jaime that he majored in accounting.

It has always puzzled me that those on the receiving end of this banter are thrown off by it. It's an every day occurrence that I, General Knowledge Dave, enlighten an individual about an aspect of their prospective future life. I see it in their faces. Ultimate Capitalist, David Blue

I believe that Brent and I remain friends because he is one of the few that shares in this mentality to some extent.

I also realized just how much more I understand my Pride and how it affects my behavior in school than I did immediately after high school. In this journey into MU, I sense that a never-before-seen part of me will emerge, finally, and it is one of ruthless competitiveness. I enter the J-School expecting to destroy everything.

"Auto journalists only make sense to other auto journalists."

I CANNOT forget how important it is for me to DISCUSS in order to work things over. Study groups and academic socializing, in general, must become the new norm.

In mulling over the fundamental nature of a media career, I find myself worrying about the conflict between The Companion and this massive adventure I'm dreaming of. It makes me wonder if my excitement for Denise's "have a really good time and then pass it along" life philosophy is simply because I am currently alone. Will I have to choose between the two? Would I ever choose a healthy media career over The Companion? It's a joke to even ask.