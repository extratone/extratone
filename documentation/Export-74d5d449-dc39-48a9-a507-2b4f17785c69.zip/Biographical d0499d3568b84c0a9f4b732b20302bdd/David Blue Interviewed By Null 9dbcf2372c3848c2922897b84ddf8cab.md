# David Blue Interviewed By Null

[David%20Blue%20Interviewed%20By%20Null%209dbcf2372c3848c2922897b84ddf8cab/Null_Interview_Voice_Notes.mp3](David%20Blue%20Interviewed%20By%20Null%209dbcf2372c3848c2922897b84ddf8cab/Null_Interview_Voice_Notes.mp3)

- **Transcript of the above voice notes file**

    Um, I had actually a bit of success doing serious content before drywall. I had a tech YouTube channel that had but a few views on a few things. I mean really, just bad unboxings and bad reviews from a 13 year old. I even had a gun review actually on my biggest channel, which also has my flying stuff.

    And that Channel had almost 100,000 views. I think when I took it down, but drywall in terms of learning experiences when you're when you're just producing content in so many different forms and you're constantly doing that, you tend to hone skills in the process as a result of doing this stuff for so long I.

    Have quite a bit of experience with video, audio, digital audio workstations. To a certain extent, I just haven't an understanding of audio and video. An editing of course, both those editing, recording, even music theory actually to it's a certain extent, I think I inadvertently.

    Through drywall.

    Kind of I don't know. I'm not gonna say that I'm actually like a musician or anything really, but I kind of honed a set of skills and it even reflects into the piano stuff that I do. Which is the most serious.

    Music that I release.

    But it's also worth noting on the previous question.

    That in that dropping all standards I tried it to completely remove any filter that I had or any criticism of my own work an an to just release things. Just recorded them and release them immediately without any standards an I think.

    It might have partially been an insecurity 'cause I looked back on a lot of the content that I had produced and really tried on in childhood. And of course it wasn't very good. And that was just made me cringe so much that I was just like, well, what if we just make stuff that that is not trying and an it's obvious that you know we're not trying and that kind of removes me. Exempts me from criticism from myself, of course, and from.

    Anyone else and that nonsensical nature is really just. It's like a weapon of confusion, really.

    It's using confusion as a.

    As a weapon. Not that I have that many people judging my content necessarily other than me.

    But

    Drywall continues.

    To its function is basically a United Banner.

    Um, other things that I continue to produce continue to produce tricast, obviously.

    Had a commitment to that episode 36 what we just finished, and that's probably the longest that I've done anything regularly, ever. Probably except for the original vlog series, where every day I would just record my high school lunch table and.

    But

    Yeah, drywall doesn't, it's not.

    About success, necessarily? Um, I've always had the mentality that you know I, or at least when I grew up when I grew out of that, everything is art stage. I kind of just accepted that I was never really going to have much of an audience. There's just no reason for me to have an audience.

    And that's really because I think that my most unique value, or the one that has the potential to really give me places I guess, comes can only come from when I sort of let the filter down and it takes a lot of repetition. But I will say insightful things after a while. It's if you watched hockey, you notice that they most of all kiss me saying the same thing over and over again, but then.

    After doing that thought process come across something that's actually be worthwhile, so I guess that's really the definition of the expression hit or miss.

---

**PREFACE:** In this interview, I will speak frankly and honestly about myself. Restraint for the sake of appearing less admiring of myself is a waste of time in a place like this. Have no fear, I regard myself no higher than most healthy people regard themselves.

**What were you first plans for Drywall? And how did it expand to what it is today?**

Drywall was, ultimately, I think, my extremely strange way of dealing with adolescence, identity, post-religion, nihilism, artistic standards, and academic pressure.

After a young childhood full of an obsession with creating content (video, photo, audio, and written,) I was working under something like 12 different names (YouTube channels, blogs, etc,) and I decided the best option to optimize my tendency to cycle through interests was to unite everything under one banner. I came to this decision Junior year of high school, during a phase where I was rejecting all the serious work I'd done in the past, and trying to produce an overwhelming amount of content that was truly meaningless, (Specifically, music and poetry,) with the mindset that with enough garbage YouTube videos getting 5,10,50 views, it would eventually add up. (and it did. I made YouTube partner with nothing but high school lunch table vlogs.) During the summer and fall of 2011, I recorded Hamura, the debut Drywall album, and I consider its release date (October 28th, 2011) to be the true birth of Drywall and David Blue. The album itself features sounds of a treadmill, turn signal indicators, the sound of a vhs tape being repeatedly slid in and out of its case, an original, hand-made native american 5-holed flute, and other nonsense. During the time, I was heavily influenced by the Columbia grind/punk scene (a lot of my friends were heavily involved in it,) in that I was trying to make angry-sounding ANTI-music that contained absolutely zero human emotion. I planned to record music that could have absolutely zero function as music. Children of the Corn 30 is a (matured) reflection of that mentality in the film medium. Key Parts of the Drywall alter (Drywall is actually a virtual band contained within the alter's alter's) included drinking gasoline, eating industrial waste, an obsession with clipping, and fear of sine waves and living in a storm drain surrounded by a pile of analog electronics. Around this time, my friends and I were "ironically" listening to noise tapes (I was new to obscure human interests, in general, and therefore very entertained by them,) ((the core of the David blue Alter is a worship of human variety, and this is the time that began for me)) The image of drywall involves a Thai Air Force jumpsuit, fairy wings, and obscure tribal instruments. In his storm drain, he records himself shrieking all day. If you wait outside the entrance long enough, a cassette containing these sounds will eventually fly out.

I'd spent a lot of time much time throughout my childhood trying to produce content that was "technically good" as I was caught up in the early days of YouTube and tech journalism and emulating people like Mark Watson and Jon Rettinger. I had thought I was going to be a professional pilot for most of my life, and I produced a sort of vlog series for every lesson I took as a student pilot. This gained more views, technically, than anything else I've ever done on the net, but I took it down long ago. My expression of "teen angst" was rejecting excellence completely in favor of quantity, my only "teen rebellion" was one against my former self. I flipped completely, and ceased all criticism of my own work, and began releasing as much content as I could indiscriminately. I created a twitter account for Drywall (@ihadtopee,) and I would literally just post random characters or zalgo text when TweetDeck allowed tweeting with just the enter key until I hit my Tweet cap every night. In general, I just rejected the idea of "good" art or "good" content and went into this state where everything was "art" and nothing meant anything. After escaping a radical Christian environment (which insisted upon the idea that everything had meaning,) I think I was just enjoying a sort of intellectual toddlerhood as I was encouraged to love what I could perceive for the first time, and was socialized. My childhood isolation and content obsession meant I was completely unable to have an actual conversation with people my own age. Once I saw that there was actual worth in my peers, I started regarding my previous work as tremendously cringeworthy. I think in part to preserve my pride, I set out to intentionally remove any intent from my content production. (I've always fetishised apathy.) As long as it's obvious we're not trying, we're exempt from criticism. It's so nonsensical it could be considered a "weapon of confusion," even.

Projects like *Children of the Corn 30* and *Drycast* represent a matured expression of these ideals. The adolescent insecurity is long gone, I think, and what's left is an absolute love of variety. This means that I'm totally comfortable with taking pride in what I do, putting effort into the quality of the medium and the packaging, but the unique brand of thought, perspective, and analysis remains - it's just more clearly communicated. *Drycast* is a sort of people-journalism mechanism. It's an anti-podcast in that its explicit purpose is maximum variety.

And sure, it'll never be successful outside of the very small group that identify and enjoy our way of doing things, but I'm actually very proud of it. In my crazy-ass subjectivity, I find it more entertaining than anything else of its kind. In fact, that's a general rule with everything I create. I know most of it is never going to be very valued by anyone else, but I'm more entertained by my set of creations than equivalent offers from anybody else, which isn't as delusional as it sounds, when you think about it. I think it indicates that I'm making the content I want to make.

I have a bad habit of telling people "this is the best episode of *Honk* yet," or "this is the best Drywall video yet," or "this is the best *Drycast* episode yet." When I do use that language, I genuinely believe it - it has nothing to do with hype. Ideally, I'd say it about every new piece of content I create. Though it depends, of course, on the natural fluctuations and cycles of focus, I say it about most.

**Do you enjoy your success with your project? (Not only considering hits, learning experiences etc.)**

My childhood endeavors were actually more successful in terms of engagement than Drywall as a whole. My aviation YouTube channel had nearly 100,000 total views before I shut it down, and my shitty tech channel (bad unboxings, useless reviews) had about as much as the Drywall channel has now after just a few months.

Drywall continues what I've been doing for my entire life, it just unifies whatever I feel like doing at the moment under one banner. The result of so many years of content-obsessiveness is a relative competence and familiarity with video and audio (design, recording, and editing,) writing, and any aspect of contemporary net content production you can think of. When you're constantly switching between mediums, you tend to hone a ton of different skills in the process. Drywall even inadvertently sharpened my knowledge of music theory, in my effort to completely ruin it.

I realized that my strength lies not with creating content for a specific purpose or audience. My only valuable contributions, really, are little bits of profound insight amidst torrents of repetitive, unfiltered garbage. My best work only comes when my mind is allowed off the leash. (*Honk* is probably the best representation of this.) It took me awhile to figure it out about myself, but it's definitely how I tick. The formula is patterns of repetition as a sort of foundation, and layers of small, in-the-moment (improvised) deviations on top of it, eventually adding up to something genius or profound, every once in awhile. This intentional lack of preparation to encourage instinctual genius makes for a very jazzy method of thought, I suppose. You can see it most literally manifested in my piano improvs. They tend to be very boring unless you're really listening for the deviations. In talking, video, or audio, it means lots and lots of mediocre thinking-out-loud for every useful or insightful argument. It's the definition of the expression "hit or miss." Drywall, originally, was the process of rejecting standards and preference and combating my filter. I think I have a bit of a reputation for being funny, but all of the worthwhile humor I've sent into the world has just been a side-effect of creating with a purpose other than explicit comedy. This is why I find standup comedy to be utterly ridiculous. I'm funnier than George Lopez when I'm trying to instill fear of overpopulation into my audience. "At this location, at this time, I am going to be funny" is just ridiculous.