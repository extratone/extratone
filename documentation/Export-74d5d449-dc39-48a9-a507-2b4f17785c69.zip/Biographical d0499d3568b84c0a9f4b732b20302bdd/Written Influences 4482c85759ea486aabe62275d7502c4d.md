# Written Influences

- Whoever wrote the 1990 Geo Metro Owner's Manual
- Louise Glück
- Beverly Cleary
- Denise McCluggage
- Jeremy Clarkson
- Edgar Allan Poe