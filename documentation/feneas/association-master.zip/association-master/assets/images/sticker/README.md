Sticker design by lostinlight, licensed under "WTFPL",
copyright "Copyheart", except where otherwise mentioned in files.

Content mirrored from [here](https://gitlab.com/lostinlight/per_aspera_ad_astra/tree/master/feneas).
