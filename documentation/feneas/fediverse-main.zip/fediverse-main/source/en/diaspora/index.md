
---
layout: "diaspora"
title: "diaspora"
network: "diaspora"
subtitle: "social network where you are in control"
banner: "/img/diaspora-bg.jpg"
percent: "87% 42%"
---
