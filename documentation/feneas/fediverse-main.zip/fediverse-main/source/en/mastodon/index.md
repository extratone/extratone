
---
layout: "mastodon"
title: "Mastodon"
network: "mastodon"
subtitle: "find your perfect community"
banner: "/img/mastodon-bg.jpg"
percent: "60% 90%"
---
