
---
layout: "fediverse"
title: "About Fediverse"
subtitle: "diversity is strength"
banner: "/img/fediverse-bg.jpg"
percent: "50% 50%"
---
