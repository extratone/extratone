
---
layout: "friendica"
title: "Friendica"
network: "friendica"
subtitle: "keep in contact with people you care about"
banner: "/img/friendica-bg.jpg"
percent: "65% 90%"
---
