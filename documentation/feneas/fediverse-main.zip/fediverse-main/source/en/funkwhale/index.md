
---
layout: "funkwhale"
title: "Funkwhale"
network: "funkwhale"
subtitle: "a social platform to enjoy and share music"
banner: "/img/funkwhale-bg.jpg"
percent: "100% 20%"
---
