
---
layout: "knowledge"
title: "Knowledge"
subtitle: "the truth isn't always beauty, but the hunger for it is"
banner: "/img/knowledge-bg.jpg"
percent: "50% 50%"
---
