
---
layout: "gnusocial"
title: "GNU Social"
network: "gnusocial"
subtitle: "connecting free libre communities across the web"
banner: "/img/gnusocial-bg.jpg"
percent: "65% 100%"
---
