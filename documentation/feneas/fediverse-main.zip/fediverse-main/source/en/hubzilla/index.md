
---
layout: "hubzilla"
title: "Hubzilla"
network: "hubzilla"
subtitle: "powerful tool for a decentralized nomadic identity"
banner: "/img/hubzilla-bg.jpg"
percent: "20% 55%"
---
