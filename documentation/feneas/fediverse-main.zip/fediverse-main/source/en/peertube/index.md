
---
layout: "peertube"
title: "PeerTube"
network: "peertube"
subtitle: "take back the control of your videos"
banner: "/img/peertube-bg.jpg"
percent: "45% 15%"
---
