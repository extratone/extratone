
---
layout: "post"
title: "Contributors wanted (updated)"
date: 2018-06-21
updated: 2018-06-21
tags:
    - fediverse
preview: "Anyone who knows Python / VueJS or wants to learn those is very welcome to join and help improve The-Federation.Info stats"
url: "/en/post/fediverse-info-contributors-wanted"
lang: en
authors: [{"name": "@lostinlight", "url": "https://mastodon.xyz/@lightone", "network": "mastodon"}]
---

Now that The-Federation.Info includes diaspora, OStatus and ActivityPub powered networks, it's the time to join and help squashing bugs and resolving [issues](https://github.com/thefederationinfo/the-federation.info/issues). If you know someone fluent in Python / VueJS or someone who wants to learn those, please, spread the word that they are very welcome to join the project and will get initial help to start contributing. Thanks!

Initial call for contributors was published [here](https://socialhome.network/content/1092839/organization-news-the-federation-info-is-now).
