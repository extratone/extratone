
---
layout: "post"
title: "diaspora* features and bounties"
date: 2018-04-04
updated: 2018-04-04
tags:
    - diaspora
preview: "New feature — client-side picture resize — merged in diaspora* develop brunch, will soon be available. Author got a $200 bounty. Take a bounty too"
url: "/en/post/diaspora-features-bounties"
lang: en
authors: [{"name": "@lostinlight", "url": "https://mastodon.xyz/@lightone", "network": "mastodon"}]
---

New feature — client-side picture resize — was recently merged in develop branch. Previously trying to upload  a large (20MB) image to diaspora* would have resulted in error message “Max image size is 4MB”. Now, it is resized before being sent. Thank you @Fred, and congrats for the $200 bounty!
More diapsora* bounties [here](https://www.bountysource.com/teams/diaspora).
Read Fla's [post](https://diaspora-fr.org/posts/3444111) on the matter.
