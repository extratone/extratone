
---
layout: "post"
title: "Toot toot"
date: 2018-06-05
updated: 2018-06-05
tags:
    - mastodon
preview: "Tootle is a new Linux GTK3 client for elementary OS and Mastodon. Confirmed to also work with Pleroma. Already available in elementary OS AppCenter"
url: "/en/post/native-linux-client-tootle"
lang: en
authors: [{"name": "@lostinlight", "url": "https://mastodon.xyz/@lightone", "network": "mastodon"}]
---

[Tootle](https://github.com/bleakgrey/tootle) is a new Linux GTK3 client for elementary OS and Mastodon. Users confirmed that it also works with Pleroma. Available in elementary OS [AppCenter](https://appcenter.elementary.io/com.github.bleakgrey.tootle.desktop).
