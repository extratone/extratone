
---
layout: "post"
title: "Hubzilla HowTo"
date: 2018-07-12
updated: 2018-07-12
tags:
    - hubzilla
preview: "Disroot community created a comprehensive HowTo about Hubzilla. Check it out to know more about Hubzilla features (news by @paulfree14@todon.nl)"
url: "/en/post/hubzilla-howto-by-disroot"
lang: en
authors: [{"name": "@lostinlight", "url": "https://mastodon.xyz/@lightone", "network": "mastodon"}]
---

Disroot community created a comprehensive HowTo about Hubzilla. [Check](https://howto.disroot.org/en/dishub) it out, to know more about Hubzilla features.
News submitted by @paulfree14@todon.nl
